# Assignment 1: Data Structure and Algorithm
# Name: Sri Rafhanah Bte Rudi
# Admin No : 214107Y
#!/usr/bin/env python

#Initialization of the customer names from the list
customer_name = ["Sara 'Black Canary' Lance", "Calvin 'Martian Manhunter' Swanwick",
    "Tara Markov", "John Constantine",
    "Arthur 'Aquaman' Curry", "Oliver 'Green Arrow' Queen",
    "Hal 'Green Lanturn' Jordan", "Kate 'Batwoman' Kane",
    "Kara 'Supergirl' Zor-el", "Diana 'Wonder Woman' Prince"
]

#Initialization of the package names from the list
package_name= [
    "Early Birds", "Family Bundle",
    "Couple Sharing", "Monthly Stays",
    "Employee Bundle","Voucher Bundle",
    "Inhouse Chef","Chauffuer Inclusive",
    "Wellness Program","Support Staff",
]

#Initialization of the package costs dictionary. This dictionary holds costs for each package name
package_cost = {
    "Early Birds": 100, "Family Bundle": 200,
    "Couple Sharing": 3000, "Monthly Stays": 400,
    "Employee Bundle": 500, "Voucher Bundle": 600,
    "Inhouse Chef": 700, "Chauffuer Inclusive": 800,
    "Wellness Program": 1200, "Support Staff": 1900,
}

#Initialize the booked clients dictionary. This dictionary holds clients and the packages booked
booked_clients = {
    "Sara 'Black Canary' Lance": ["Early Birds", 2],
    "Calvin 'Martian Manhunter' Swanwick": ["Family Bundle", 1],
    "Tara Markov": ["Couple Sharing", 5],
    "John Constantine": ["Monthly Stays", 30],
    "Arthur 'Aquaman' Curry": ["Employee Bundle", 3],
    "Oliver 'Green Arrow' Queen": ["Voucher Bundle", 5],
    "Hal 'Green Lanturn' Jordan": ["Inhouse Chef", 2],
    "Kate 'Batwoman' Kane": ["Chauffuer Inclusive", 1],
    "Kara 'Supergirl' Zor-el": ["Wellness Program", 12],
    "Diana 'Wonder Woman' Prince": ["Support Staff", 30],
}
details_by_name = [
    ["Sara 'Black Canary' Lance", "Early Birds", "2 pax"],
    ["Calvin 'Martian Manhunter' Swanwick", "Family Bundle", "1 pax"],
    ["Tara Markov", "Couple Sharing", "5 pax"],
    ["John Constantine", "Monthly Stays", "30 pax"],
    ["Arthur 'Aquaman' Curry", "Employee Bundle", "3 pax"],
    ["Oliver 'Green Arrow' Queen", "Voucher Bundle", "5 pax"],
    ["Hal 'Green Lanturn' Jordan", "Inhouse Chef", "2 pax"],
    ["Kate 'Batwoman' Kane", "Chauffuer Inclusive", "1 pax"],
    ["Kara 'Supergirl' Zor-el", "Wellness Program", "12 pax"],
    ["Diana 'Wonder Woman' Prince", "Support Staff", "30 pax"],
]
details_by_package = [
    ["Early Birds", "2 pax", "Sara 'Black Canary' Lance"],
    ["Family Bundle", "1 pax", "Calvin 'Martian Manhunter' Swanwick",],
    ["Couple Sharing", "5 pax", "Tara Markov",],
    ["Monthly Stays", "30 pax", "John Constantine",],
    ["Employee Bundle", "3 pax", "Arthur 'Aquaman' Curry"],
    ["Voucher Bundle", "5 pax", "Oliver 'Green Arrow' Queen"],
    ["Inhouse Chef", "Hal 'Green Lanturn' Jordan", "2 pax"],
    ["Chauffuer Inclusive", "Kate 'Batwoman' Kane", "1 pax"],
    ["Wellness Program", "12 pax", "Kara 'Supergirl' Zor-el"],
    ["Support Staff", "30 pax", "Diana 'Wonder Woman' Prince"],
]


class DealsInventory:
    """The purpose of the system is to allow a renowned hotel to manage the
    Staycation booking records for the packages they offered. They can display
    and update staycation booking records from the system. User can perform
    searching and sorting of records.

    The approach taken is to have a class DealsInventory with methods and objects
    to handle all the functionalities of the system.
    """

    def __init__(self, customer_name, package_name, package_cost, booked_clients, details_by_name, details_by_package): #Use the __init__ method to initialize the attributes to be used throughtout the class.
        self.customer_name = customer_name
        self.package_name = package_name
        self.package_cost = package_cost
        self.booked_clients = booked_clients
        self.details_by_name = details_by_name
        self.details_by_package = details_by_package
    def display_all_records(self): #This function prints all the records available in our data structures
        print("\nList of Customers: ")
        print("------------------")
        # for loop to print customer names
        for item in self.customer_name:
            print(item)

        print("\nList of Packages: ")
        print("-----------------")
        # for loop to print package names
        for item in self.package_name:
            print(item)

        print("\nList of Package Costs: ")
        print("----------------------")
        # for loop to print package costs
        for item, value in self.package_cost.items():
            print(f"{item}: ${value}")

        print("\nList of Booked Clients: ")
        print("-----------------------")
        # for loop to print booked clients
        for item, value in self.booked_clients.items():
            if value[1] == 1:
                print(f"{item}: {value[0]} for {value[1]} person")
            else:
                print(f"{item}: {value[0]} for {value[1]} people")

    def customer_bubble_sort(self):
        """
        Sort record by Customer Name using Bubble sort
        """
        list_size = len(self.details_by_name)  # length of the customer_name list

        # for loop to get range
        for i in range(list_size - 1):
            reversed_list = False  # list items positions have not been reversed yet
            for j in range(list_size - 1 - i): # if second range item is greater than first range item, list has been reversed
                if self.details_by_name[j] > self.details_by_name[j + 1]:
                    reversed_list = True
                    self.details_by_name[j], self.details_by_name[j + 1] = (self.details_by_name[j + 1], self.details_by_name[j],)
            if not reversed_list:
                break  # halt the iteration once the items have been sorted
        print("Customer Names have been Sorted using Bubble sort method!: \n")
        for item in self.details_by_name:
            print(item[0], ":", ": ".join(map(str, item[1:]))) # print the sorted items

    def package_name_selection_sort(self):
        """
        Sort record by Package Name using Selection sort
        """
        list_size = len(self.details_by_package)  # create variable for size of package_name list
        for i in range(list_size - 1): # for loop to get minimum value in the list
            minimum_value = i
            for k in range(i + 1, list_size):
                if self.details_by_package[k] < self.details_by_package[minimum_value]: minimum_value = k  #keep finding the minimum value
            if (minimum_value != i):
                self.details_by_package[minimum_value], self.details_by_package[i] = (self.details_by_package[i],self.details_by_package[minimum_value],)
        print("Package Names have been Sorted using Selection sort method!: \n")
        for item in self.details_by_package:
            print(item[0], ":", ": ".join(map(str, item[1:])))
          # print sorted items

    def package_cost_insertion_sort(self):
        """
        Sort record by Package Cost using Insertion sort
        """
        cost_list = []  # initialize empty list
        x = {}  # initialize empty dictionary
        for (item,value) in (self.package_cost.items()):  # for loop to store the dictionary values in cost_list
            cost_list.append(value)

        # insertion sort process
        for position, value in enumerate(cost_list[1:]):
            holding_index = position

            while position >= 0 and value < cost_list[position]:
                cost_list[position + 1] = cost_list[position]
                position -= 1

            if position != holding_index:
                cost_list[position + 1] = value

        for (value) in (cost_list):  # for loop to add data to empty dictionary using sorted data as key value pairs
            for item, val in self.package_cost.items():
                if value == val:
                    x[item] = val
        print("Package Cost have been Sorted using Insertion sort!: \n")
        for item, value in x.items():
            print(f"{item}: ${value}")  # print sorted data

    def customer_linear_search(self, searched_name):
        """
        Search record by Customer Name using Linear Search and update record
        """

        # for loop to search the given input linearly
        for position, name in enumerate(self.customer_name):
            name = name.lower()
            if name == searched_name:
                return position

        return -1

    def package_name_stooge(self, unsorted_list, first_element, last_element):
        """
        The stooge sort algorithm to sort the package name list and return it to be used in the binary search function for
        the package name list.
        """

        if first_element >= last_element:
            return None

        if unsorted_list[first_element] > unsorted_list[last_element]:
            unsorted_list[first_element], unsorted_list[last_element] = (
                unsorted_list[last_element],
                unsorted_list[first_element],
            )

        if last_element - first_element + 1 > 2:
            two_thirds = (int)((last_element - first_element + 1) / 3)

            # sort two thirds of the elements
            self.package_name_stooge(unsorted_list, first_element, (last_element - two_thirds))

            # sort two thirds of the elements
            self.package_name_stooge(unsorted_list, first_element + two_thirds, (last_element))

            self.package_name_stooge(unsorted_list, first_element, (last_element - two_thirds))

        return unsorted_list

    def package_name_binary_search(self, sorted_package_names, searched_package_name):
        """
        Search record by Package Name using Binary Search and update record
        """

        beginning = 0  # position of first item
        end = len(sorted_package_names) - 1  # position of last item

        # while loop to search for the item using binary search
        while beginning <= end:
            middle = beginning + (end - beginning) // 2
            current_item = sorted_package_names[middle]
            current_item = current_item.lower()

            if current_item == searched_package_name:
                return middle

            elif searched_package_name < current_item:
                end = middle - 1

            else:
                beginning = middle + 1

        return None

    def records_range(self):
        """List records range from $X to $Y. e.g $100-200. The object asks the user to enter a range
        and then the object prints out all the items in the range
        """
        print("We have all sorts of packages that range from cheap to expensive. Please enter values here: ")
        lower_range = int(input("Enter lower value: "))  # ask for lower limit
        upper_range = int(input("Enter upper value: "))  # ask for upper limit

        if lower_range or upper_range < 100:
            print("The amount is too low. Please enter a more appropriate value")

        else:
            print("These are packages are available!")

        # for loop to get all items in that range
        for items, value in self.package_cost.items():
            if value >= lower_range and value <= upper_range:
                print(f"{items} : ${value}")



def main():
    """Main function to carry out the tests to ensure that the class works. It
    also displays the data acting as a user interface.
    """

    working_class = DealsInventory(customer_name, package_name, package_cost, booked_clients, details_by_name,details_by_package )  # pass our class to the working_class object
    print("________________________________________________________________________________")
    # making the interface user friendly
    print("\t \t \t \t \t \t Welcome To The Heroes Hotel!")
 # making the interface user friendly

    # while loop to ensure the program is only terminated if the user types 0
    while True:
        print("____________________________________________________________________________")

        # program menu
        print("1: Display all records")
        print("2: Sort record by Customer Name using Bubble sort")
        print("3: Sort record by Package Name using Selection sort")
        print("4: Sort record by Package Cost using Insertion sort")
        print("5: Search record by Customer Name using Linear Search and update record")
        print("6: Search record by Package Name using Binary Search and update record")
        print("7: List records range from $X to $Y. e.g $100-200")
        print("0: Exit Application ")
        print("____________________________________________________________________________\n")

        try:  # error handling
            user_input = int(
                input("Please choose an item from the menu (or type 0 to exit): ")

            )
            # ask user for input
            if user_input == 0:
                break  # end the program if user inputs 0

            elif user_input == 1:
                working_class.display_all_records()

            elif user_input == 2:
                working_class.customer_bubble_sort()

            elif user_input == 3:
                working_class.package_name_selection_sort()

            elif user_input == 4:
                working_class.package_cost_insertion_sort()

            elif user_input == 5:
                searched_name = input(
                    "Enter name to be searched separated by space: "
                )  # ask user for the value to be searched
                # create case insensitivity by converting input to lowercase
                searched_name = searched_name.lower()
                results = working_class.customer_linear_search(searched_name)
                if results == -1:
                    update_record = input(
                        # if name is not found, ask the user to update the name
                        "Name not found. Enter name to update separated by space:"
                    )
                    update_record = update_record.lower()  # Ensure case sensitivity
                    customer_name.append(
                        update_record.title()
                    )  # append user input to appropriate list
                    print(
                        "Record has been updated!"
                    )  # inform user the name has been updated successfully
                    print(*customer_name, sep="\n")  # print the new list
                else:
                    print(f"\n{searched_name.title()} is number {working_class.customer_linear_search(searched_name) + 1} in our list.")
                    for index, value in booked_clients.items():
                        if index.lower() == searched_name:
                            if value[1] == 1:
                                print(f"{searched_name.title()} has booked for the {value[0]} package for {value[1]} person.")
                            else:
                                print(f"{searched_name.title()} has booked for the {value[0]} package for {value[1]} people.")
                            for item, cost in package_cost.items():
                                if value[0] == item:
                                    print(f"{searched_name.title()} has paid ${value[1] * cost} for the package.")
                    update_decision = input(
                        "Enter yes or no if you want to update customer record: "
                    ).lower()
                    if update_decision == "yes":
                        print("Here are the bundles available\t")
                        new_package = input(
                            "Type preferred name here: \n"
                            "\nEarly Birds\n"
                            "Family Bundle\n"
                            "Couple Sharing\n"
                            "Monthly Stays\n"
                            "Employee Bundle\n"
                            "Voucher Bundle\n"
                            "Inhouse Chef\n"
                            "Chauffuer Inclusive\n"
                            "Wellness Program\n"
                            "Support Staff\n"
                            "\n---> "
                        )
                        new_pax = int(input("Type new pax in figures: "))

                        booked_clients[searched_name.title()] = [new_package.title(),new_pax,]
                        print("Client's booking information has been updated.")

            elif user_input == 6:
                searched_package_name = input(
                    "Enter package name to be searched separated by space: "
                )  # ask user for name to be searched
                searched_package_name = (
                    searched_package_name.lower()
                )  # enforce case insensitivity
                i = 0
                h = len(package_name) - 1
                search_results = working_class.package_name_binary_search(
                    working_class.package_name_stooge(package_name, i, h),
                    searched_package_name,
                )
                if search_results == None:
                    enter_record = input(
                        # if the while loop does not find the name, inform user and ask them to update
                        f"{searched_package_name.title()} was not found. Enter record to update separated by space: "
                    )
                    enter_record = enter_record.lower()

                    package_name.append(enter_record.title())
                    print("Record has been updated!")
                    print(package_name, sep="\n")  # print updates list using a new line

                else:
                    print(
                        f"The {searched_package_name.title()} package is available in our packages list."
                    )
                    for index, value in package_cost.items():
                        if index.lower() == searched_package_name:
                            print(
                                f"The cost of {searched_package_name.title()} is ${value}"
                            )
                    update_record_decision = input(
                        "Enter Yes if you want to update the package price or No to go to the main menu: "
                    ).lower()
                    if update_record_decision == "yes":
                        new_price = int(input("Enter new price in numbers: "))
                        package_cost[searched_package_name.title()] = new_price
                        print(f"Price updated. New price is ${new_price}")

            elif user_input == 7:
                working_class.records_range()

            else:
                print("We did not understand your query. Try again.")

        except:
            return print("Wrong Input. Please restart.")


if __name__ == "__main__":
    main()